let summarizeButton = document.getElementById('summarize_button');
let textField = document.getElementById('paragraph_field');


//Summarize button onClickListener
summarizeButton.addEventListener ("click", async () => {

    //Get current tab
    let [tab] = await chrome.tabs.query({active: true, currentWindow: true});
    
    //Execute script to parse text on page
    chrome.scripting.executeScript({
        target: {tabId: tab.id},
        func: scrapeTextFromPage
    });
})

//Function to scrape text from a page
function scrapeTextFromPage() {
    
    //Scrap text
    let text = document.getElementsByTagName('p')[0].innerHTML;

    //Send text to handler
    chrome.runtime.sendMessage({text}, function(response) {
        if (response.farewell != null){
            alert('Data received from python script: ');   
        }
        // if(text == null) {
        //     textField.innerHTML = "No text("
        // } else {
        //     textField.innerHTML = text
        // }
    });
}