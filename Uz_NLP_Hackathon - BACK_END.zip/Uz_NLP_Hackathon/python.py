# import sys
# data_to_pass_back = 'Send this to node process.'

# incoming_input = sys.argv[0]
# output = data_to_pass_back
# print(output)
# sys.stdout.flush()

import sys
from transformers import pipeline
# from transformers import AutoTokenizer, AutoModelForSequenceClassification, BartForConditionalGeneration, BartTokenizer
from googletrans import Translator

f_path = """Do you know someone thinking about joining the Calyx Institute? Tell your family, friends, and neighbors because the Calyx referral program is now live!" + 
Starting today, every person you refer to the Calyx Institute gets a 
free extra month of membership benefits - one more month to enjoy unlimited and unthrottled internet!
Even better, you also get one extra month per referral. 
If you refer three people, thats three extra months! With no caps on the 
number of people you refer, you can help spread the word on unlimited and unthrottled internet while helping yourself to some extra membership time.

We are very grateful to our membership community who have greatly increased our membership base through word of mouth. Your support has allowed us to continue building CalyxOS,
 developing free digital privacy services, 
hiring more staff, and more! Make sure you take advantage of the referral program today!"
"""
translator = Translator()

summarizer = pipeline(task='summarization')

result = summarizer(f_path, max_length=130, min_length=10, do_sample=False)
result = result[0]['summary_text']
result = translator.translate(result, dest="uz")
print(result.text)
sys.stdout.flush()
