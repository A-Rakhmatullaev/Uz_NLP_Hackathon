// const express = require('express'); //requires express module
// const fs = require('fs');
// const app = express();


// var PORT = process.env.PORT || 3000;
// const server = app.listen(PORT);


// app.use(express.static('public'));

// app.post(route, function(req, res){
//     //this is a callback function
// })


const express = require('express');
const app = express();
app.use(express.json());
const PORT = 4000;

//Python
const spawn = require('child_process').spawn;

app.listen(PORT, "192.168.1.118" || "localhost", () => {
    console.log(`Server is running on ${PORT}`)
});

app.get('/getRequest', (req, res) => {
    res.send("Hello guys")
});


app.post('/postRequest', (req, res) => {
    // //console.log(`Request body: ${req}`)
    // //Python Part
    // var dataToSend;
    // //Spawn new child process to call the python script
    // const python = spawn('python3', ['python.py'], {shell: true});
    // //Collect data from script
    // python.stdout.on('data', (data) => {
    //     console.log('Pipe data from python script ...');
    //     dataToSend = data;
    //    });

    // python.on('close', (code) => {
    //     console.log(`child process close all stdio with code ${code}`);
    //     //Send data back to sender
    //     res.send({text: `${dataToSend}`})
    // });


    console.log(req.body());
    const { exec } = require('child_process');
    exec('python3 python.py', (error, stdout, stderr) => {
    if (error) {
        console.error(error);
        return;
    }
    console.log(stdout);
    var dataToSend = stdout
    res.send({text: `${dataToSend}`});
    console.error(stderr);
    });
});