//Handler to receive text from scraper function
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {

    //Get text
    let text = request.text;
    if(text == null) {
        sendResponse({farewell: "No Data is Provided!"});
    } else {
        sendResponse({farewell: "Data is Processed!)"});
    }
})

//API Request
function sendDataToBack(message) {
    var jqXHR = $.ajax({
        type: "POST",
        url: "/python.py",
        data: { param: message },
        success: callbackFromBack
    });
}

function callbackFromBack(response) {

}

sendDataToBack('BackEnd')

//python communication part
// import { spawn as spawner } from 'child_process';
// const data_to_transfer = 'Some String';

// const python_process = spawner('python', ['./python.py', data_to_transfer]);
// python_process.stdout.on('data', (data) => {
//     print("Hi")
// });